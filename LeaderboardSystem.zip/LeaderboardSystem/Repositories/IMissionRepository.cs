﻿using LeaderboardSystem.Models;

namespace LeaderboardSystem.Repositories
{
    public interface IMissionRepository
    {
        Task<Mission> GetByIdAsync(int id);
        Task UpdateAsync(Mission mission);
        Task<List<Mission>> GetAllAsync();
    }
}
