﻿using LeaderboardSystem.Models;
using Microsoft.EntityFrameworkCore;


namespace LeaderboardSystem.Data
{
    public class LeaderboardContext : DbContext
    {
        public LeaderboardContext(DbContextOptions<LeaderboardContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Mission> Missions { get; set; }
        public DbSet<UserMission> UserMissions { get; set; }
        public DbSet<UserReward> UserRewards { get; set; }  // Add the DbSet for UserReward

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define composite key for UserReward
            modelBuilder.Entity<UserReward>()
                .HasKey(ur => new { ur.UserId, ur.RewardId });  // Composite key with UserId and RewardId

            // Configure relationships (optional, based on your model)
            modelBuilder.Entity<UserReward>()
                .HasOne(ur => ur.User)
                .WithMany(u => u.UserRewards)
                .HasForeignKey(ur => ur.UserId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete, optional

            modelBuilder.Entity<UserReward>()
                .HasOne(ur => ur.Reward)
                .WithMany(r => r.UserRewards)  // Assuming Reward has a collection of UserRewards
                .HasForeignKey(ur => ur.RewardId)
                .OnDelete(DeleteBehavior.Cascade); // Cascade delete, optional

            // Other model configurations...
            modelBuilder.Entity<User>()
                .Property(u => u.KCCoins)
                .HasDefaultValue(0);

            modelBuilder.Entity<UserMission>()
                .HasKey(um => new { um.UserId, um.MissionId });

            modelBuilder.Entity<UserMission>()
                .HasOne(um => um.User)
                .WithMany(u => u.UserMissions)
                .HasForeignKey(um => um.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<UserMission>()
                .HasOne(um => um.Mission)
                .WithMany(m => m.UserMissions)
                .HasForeignKey(um => um.MissionId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}