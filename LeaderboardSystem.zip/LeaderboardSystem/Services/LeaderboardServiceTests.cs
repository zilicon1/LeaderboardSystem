﻿using LeaderboardSystem.Models;
using LeaderboardSystem.Repositories;
using LeaderboardSystem.Services;
using Moq;
using Xunit;
using FluentAssertions;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class LeaderboardServiceTests
{
    private readonly Mock<IUserRepository> _userRepositoryMock;
    private readonly LeaderboardService _leaderboardService;

    public LeaderboardServiceTests()
    {
        _userRepositoryMock = new Mock<IUserRepository>();
        _leaderboardService = new LeaderboardService(_userRepositoryMock.Object);
    }

    [Fact]
    public async Task GetLeaderboardAsync_ShouldReturnUsersSortedByTotalCoins()
    {
        // Arrange
        var users = new List<User>
        {
            new User { Id = 1, KC_Coins = 50, TC_Coins = 20 },
            new User { Id = 2, KC_Coins = 30, TC_Coins = 40 },
            new User { Id = 3, KC_Coins = 10, TC_Coins = 90 }
        };

        _userRepositoryMock.Setup(repo => repo.GetAllAsync()).ReturnsAsync(users);

        // Act
        var leaderboard = await _leaderboardService.GetLeaderboardAsync();

        // Assert
        leaderboard.Should().BeInDescendingOrder(u => u.KC_Coins + u.TC_Coins);
        leaderboard[0].Id.Should().Be(3); // User with most coins
        leaderboard[1].Id.Should().Be(2);
        leaderboard[2].Id.Should().Be(1);
    }

    [Fact]
    public async Task AssignSpecialCoinsToTop3Async_ShouldAssignCorrectSpecialCoins()
    {
        // Arrange
        var users = new List<User>
        {
            new User { Id = 1, KC_Coins = 50, TC_Coins = 20, SpecialCoins = 0 },
            new User { Id = 2, KC_Coins = 30, TC_Coins = 40, SpecialCoins = 0 },
            new User { Id = 3, KC_Coins = 10, TC_Coins = 90, SpecialCoins = 0 },
            new User { Id = 4, KC_Coins = 5, TC_Coins = 5, SpecialCoins = 0 }
        };

        _userRepositoryMock.Setup(repo => repo.GetAllAsync()).ReturnsAsync(users);
        _userRepositoryMock.Setup(repo => repo.UpdateAsync(It.IsAny<User>())).Returns(Task.CompletedTask);

        // Act
        await _leaderboardService.AssignSpecialCoinsToTop3Async();

        // Assert
        _userRepositoryMock.Verify(repo => repo.UpdateAsync(It.Is<User>(u => u.Id == 3 && u.SpecialCoins == 500)), Times.Once);
        _userRepositoryMock.Verify(repo => repo.UpdateAsync(It.Is<User>(u => u.Id == 2 && u.SpecialCoins == 300)), Times.Once);
        _userRepositoryMock.Verify(repo => repo.UpdateAsync(It.Is<User>(u => u.Id == 1 && u.SpecialCoins == 100)), Times.Once);
        _userRepositoryMock.Verify(repo => repo.UpdateAsync(It.Is<User>(u => u.Id == 4)), Times.Never);
    }
}
