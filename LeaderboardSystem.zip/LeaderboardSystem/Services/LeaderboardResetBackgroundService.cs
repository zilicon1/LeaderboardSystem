﻿using Microsoft.Extensions.Hosting;
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace LeaderboardSystem.Services
{
    public class LeaderboardResetBackgroundService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public LeaderboardResetBackgroundService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // Time zone for UTC+07:00 (Bangkok)
            TimeZoneInfo bangkokTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Asia/Bangkok");

            while (!stoppingToken.IsCancellationRequested)
            {
                // Get current UTC time and convert to UTC+07:00
                DateTime nowUtc = DateTime.UtcNow;
                DateTime nowBangkok = TimeZoneInfo.ConvertTimeFromUtc(nowUtc, bangkokTimeZone);

                // Check if today is the first day of the month at 00:00 in UTC+07:00
                if (nowBangkok.Day == 1 && nowBangkok.Hour == 0 && nowBangkok.Minute == 0)
                {
                    try
                    {
                        using (var scope = _serviceProvider.CreateScope())
                        {
                            var leaderboardService = scope.ServiceProvider.GetRequiredService<ILeaderboardService>();
                            await leaderboardService.ResetLeaderboardAsync();
                        }

                        // Sleep for a day to avoid redundant resets within the same day
                        await Task.Delay(TimeSpan.FromDays(1), stoppingToken);
                    }
                    catch (Exception ex)
                    {
                        // Log the error if something goes wrong with the leaderboard reset
                        Console.WriteLine($"Error occurred during leaderboard reset: {ex.Message}");
                    }
                }
                else
                {
                    // Sleep until the next minute if it's not yet time to reset the leaderboard
                    await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
                }
            }
        }
    }
}
