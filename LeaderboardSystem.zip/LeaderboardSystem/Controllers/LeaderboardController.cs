﻿using LeaderboardSystem.Services;
using LeaderboardSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace LeaderboardSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeaderboardController : ControllerBase
    {
        private readonly ILeaderboardService _leaderboardService;

        public LeaderboardController(ILeaderboardService leaderboardService)
        {
            _leaderboardService = leaderboardService ?? throw new ArgumentNullException(nameof(leaderboardService));
        }

        // GET: api/Leaderboard/GetLeaderboard
        [HttpGet("GetLeaderboard")]
        public async Task<IActionResult> GetLeaderboard()
        {
            try
            {
                var leaderboard = await _leaderboardService.GetLeaderboardAsync();
                return Ok(leaderboard);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Title = "Internal Server Error",
                    Detail = ex.Message,
                    Status = StatusCodes.Status500InternalServerError
                });
            }
        }

        // POST: api/Leaderboard/AssignSpecialCoins
        [HttpPost("AssignSpecialCoins")]
        public async Task<IActionResult> AssignSpecialCoins()
        {
            try
            {
                await _leaderboardService.AssignSpecialCoinsToTop3Async();
                return Ok(new { Message = "Special KC coins assigned to top 3." });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Title = "Internal Server Error",
                    Detail = ex.Message,
                    Status = StatusCodes.Status500InternalServerError
                });
            }
        }

        // POST: api/Leaderboard/ResetLeaderboard
        [HttpPost("ResetLeaderboard")]
        public async Task<IActionResult> ResetLeaderboard()
        {
            try
            {
                await _leaderboardService.ResetLeaderboardAsync();
                return Ok(new { Message = "Leaderboard reset successfully." });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new ProblemDetails
                {
                    Title = "Bad Request",
                    Detail = ex.Message,
                    Status = StatusCodes.Status400BadRequest
                });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Title = "Internal Server Error",
                    Detail = "An unexpected error occurred.",
                    Status = StatusCodes.Status500InternalServerError
                });
            }
        }

        // POST: api/Leaderboard/UpdatePoints
        [HttpPost("UpdatePoints")]
        public async Task<IActionResult> UpdatePoints([FromBody] UpdatePointsRequest request)
        {
            // Validate request
            if (request == null || request.UserId <= 0 || request.Points < 0)
            {
                return BadRequest(new ProblemDetails
                {
                    Title = "Invalid Request",
                    Detail = "UserId must be greater than 0 and Points must be non-negative.",
                    Status = StatusCodes.Status400BadRequest
                });
            }

            try
            {
                await _leaderboardService.UpdatePointsAsync(request.UserId, request.Points);
                return Ok(new { Message = "Points updated successfully." });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new ProblemDetails
                {
                    Title = "Bad Request",
                    Detail = ex.Message,
                    Status = StatusCodes.Status400BadRequest
                });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Title = "Internal Server Error",
                    Detail = "An unexpected error occurred.",
                    Status = StatusCodes.Status500InternalServerError
                });
            }
        }
    }
}
