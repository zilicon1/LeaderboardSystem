using LeaderboardSystem.Data;
using LeaderboardSystem.Repositories;
using LeaderboardSystem.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Register DbContext with SQL Server connection string
builder.Services.AddDbContext<LeaderboardContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlServerOptions => sqlServerOptions.EnableRetryOnFailure(
            maxRetryCount: 5,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorNumbersToAdd: null)));

// Register scoped services for repositories and services
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IMissionRepository, MissionRepository>(); // Added for consistency
builder.Services.AddScoped<ILeaderboardService, LeaderboardService>();

// Configure CORS (Cross-Origin Resource Sharing) policy to allow all origins, methods, and headers
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// Enable logging
builder.Services.AddLogging();

// Register controllers and add Swagger for API documentation
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add a hosted service for automatic leaderboard reset (monthly)
builder.Services.AddHostedService<LeaderboardResetBackgroundService>();

// Build the application
var app = builder.Build();

// Configure Swagger for development environment
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Use the CORS policy that was defined earlier
app.UseCors("AllowAll");

// Use authorization (make sure you have authentication and authorization logic in place)
app.UseAuthorization();

// Map the controllers (ensure that your controllers are correctly set up)
app.MapControllers();

// Run the application
app.Run();
