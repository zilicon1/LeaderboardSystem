﻿using Microsoft.AspNetCore.Mvc;

namespace LeaderboardSystem.Models
{
    public class UserMission
    {
        public int UserId { get; set; }
        public User User { get; set; }

        public int MissionId { get; set; }
        public Mission Mission { get; set; }

        public DateTime CompletedAt { get; set; } = DateTime.UtcNow;
    }
}
